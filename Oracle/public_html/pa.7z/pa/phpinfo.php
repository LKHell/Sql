<html> <head> <title> PHP Info </title> </head>
<body> 
<? phpinfo(); 
?> 
</body>
</html>
